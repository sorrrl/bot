import discord
from core.classes import Cog_Extension
from discord import app_commands

class Help(Cog_Extension):
    @app_commands.command(name = "help", description = "Show how to use")
    async def help(self, interaction: discord.Interaction):
        embed=discord.Embed(title="Help", description="\n\n**COMMANDS -**")
        embed.add_field(name="/bing", value="Chat with Bing.", inline=False)
        embed.add_field(name="/switch_style", value="Switch your Bing conversation style.", inline=False)
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Help(bot))